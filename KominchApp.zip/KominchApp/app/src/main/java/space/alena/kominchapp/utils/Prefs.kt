package space.alena.kominchapp.utils

abstract class Prefs {
    companion object {
        const val ACC_NAME = "accName"; //имя аккаунта, для которого моделируется лента - профиль
    }
}